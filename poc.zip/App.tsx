import React, { useState } from 'react';
import { Screen } from './types';
import LandingPage from './screens/LandingPage';
import Onboarding from './screens/Onboarding';
import Dashboard from './screens/Dashboard';
import ActiveConversation from './screens/ActiveConversation';
import FamilyPortal from './screens/FamilyPortal';
import ChapterDetail from './screens/ChapterDetail';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.LANDING);

  // Simple router
  const renderScreen = () => {
    switch (currentScreen) {
      case Screen.LANDING:
        return <LandingPage onNavigate={(screen) => setCurrentScreen(screen)} />;
      case Screen.ONBOARDING:
        return <Onboarding onNavigate={(screen) => setCurrentScreen(screen)} />;
      case Screen.DASHBOARD:
        return <Dashboard onNavigate={(screen) => setCurrentScreen(screen)} />;
      case Screen.ACTIVE_CONVERSATION:
        return <ActiveConversation onNavigate={(screen) => setCurrentScreen(screen)} />;
      case Screen.FAMILY_PORTAL:
        return <FamilyPortal onNavigate={(screen) => setCurrentScreen(screen)} />;
      case Screen.CHAPTER_DETAIL:
        return <ChapterDetail onNavigate={(screen) => setCurrentScreen(screen)} />;
      default:
        return <LandingPage onNavigate={(screen) => setCurrentScreen(screen)} />;
    }
  };

  return (
    <div className="w-full min-h-screen font-sans antialiased text-gray-900">
      {renderScreen()}
    </div>
  );
}