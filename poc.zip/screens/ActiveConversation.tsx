import React, { useState, useRef, useEffect } from 'react';
import { Screen } from '../types';

interface Props {
  onNavigate: (screen: Screen) => void;
}

const LANGUAGES = [
  { code: 'en-US', label: 'English', native: 'English', flag: '🇺🇸', text: "I remember the old oak tree in the backyard. It stood there for generations." },
  { code: 'es-ES', label: 'Spanish', native: 'Español', flag: '🇪🇸', text: "Recuerdo el viejo roble en el patio trasero. Estuvo allí por generaciones." },
  { code: 'fr-FR', label: 'French', native: 'Français', flag: '🇫🇷', text: "Je me souviens du vieux chêne dans l'arrière-cour. Il était là depuis des générations." },
  { code: 'de-DE', label: 'German', native: 'Deutsch', flag: '🇩🇪', text: "Ich erinnere mich an die alte Eiche im Hinterhof. Sie stand dort seit Generationen." },
  { code: 'ja-JP', label: 'Japanese', native: '日本語', flag: '🇯🇵', text: "裏庭の古い樫の木を覚えています。それは何世代にもわたってそこに立っていました。" },
];

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: number;
}

const STORAGE_KEY = 'legacy_app_conversation_state';

const INITIAL_MESSAGES: Message[] = [
  {
    id: 'msg_1',
    sender: 'ai',
    text: "That is fascinating, Arthur. You mentioned the coastline was different back then. How did that make you feel when you first arrived?",
    timestamp: Date.now() - 100000
  },
  {
    id: 'msg_2',
    sender: 'user',
    text: "Well, it was 1965, and I was stationed in San Diego. It felt vast, open. Not like the crowded beaches you see in magazines today.",
    timestamp: Date.now() - 50000
  }
];

export default function ActiveConversation({ onNavigate }: Props) {
  // State
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [isInputMode, setIsInputMode] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [selectedLang, setSelectedLang] = useState(LANGUAGES[0]);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [isThinking, setIsThinking] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load state from local storage on mount
  useEffect(() => {
    const savedState = localStorage.getItem(STORAGE_KEY);
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        if (parsed.messages && Array.isArray(parsed.messages)) {
          setMessages(parsed.messages);
        }
        if (parsed.inputText) setInputText(parsed.inputText);
        if (typeof parsed.isInputMode === 'boolean') setIsInputMode(parsed.isInputMode);
        if (parsed.languageCode) {
          const lang = LANGUAGES.find(l => l.code === parsed.languageCode);
          if (lang) setSelectedLang(lang);
        }
      } catch (error) {
        console.error("Failed to restore conversation state:", error);
      }
    }
  }, []);

  // Auto-save state when relevant data changes
  useEffect(() => {
    setIsAutoSaving(true);
    const stateToSave = {
      messages,
      inputText,
      isInputMode,
      languageCode: selectedLang.code,
      lastUpdated: Date.now()
    };
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));

    // Show saving indicator briefly
    const timer = setTimeout(() => setIsAutoSaving(false), 800);
    return () => clearTimeout(timer);
  }, [messages, inputText, isInputMode, selectedLang]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  useEffect(() => {
    if (isInputMode && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isInputMode]);

  const handleVoiceInput = () => {
    if (isListening) return;
    setIsListening(true);
    
    // Simulate voice recognition delay and transcription
    setTimeout(() => {
      setIsListening(false);
      setInputText(prev => prev + (prev ? ' ' : '') + selectedLang.text);
    }, 2000);
  };

  const handleSend = () => {
    if (!inputText.trim()) return;
    
    const newUserMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputText,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, newUserMsg]);
    setInputText('');
    
    // Simulate AI thinking and response
    setIsThinking(true);
    setTimeout(() => {
      setIsThinking(false);
      const newAiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: "I see. It sounds like a vivid memory. Did you visit the ocean often during that time?",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, newAiMsg]);
    }, 2500);
  };

  const handleEndSession = () => {
    // Optional: Clear local storage on proper end, or keep it for history?
    // For now, we keep it as "draft" history.
    onNavigate(Screen.DASHBOARD);
  };

  return (
    <div className="font-['Spline_Sans'] text-white h-screen overflow-hidden flex flex-col selection:bg-[#FFB088] selection:text-[#1F1C1A] bg-[#1F1C1A] relative">
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage: 'radial-gradient(circle at 10% 20%, rgba(255, 176, 136, 0.06) 0%, transparent 40%), radial-gradient(circle at 90% 80%, rgba(156, 197, 161, 0.04) 0%, transparent 40%)'
      }}></div>

      <header className="flex flex-col gap-4 p-6 shrink-0 z-20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 px-3 py-1.5 rounded-full flex items-center gap-2.5 shadow-sm">
              <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse shadow-[0_0_8px_rgba(248,113,113,0.6)]"></div>
              <span className="text-white/90 text-xs font-semibold tracking-wide uppercase">Live</span>
            </div>
            <div className="bg-emerald-500/10 backdrop-blur-xl border border-emerald-500/20 px-2.5 py-1.5 rounded-full flex items-center gap-1.5">
              <span className="material-symbols-outlined text-emerald-400 text-[14px]">hd</span>
              <span className="text-emerald-200/90 text-[10px] font-bold tracking-wider uppercase">High Fidelity</span>
            </div>
          </div>
          
          <div className="absolute left-1/2 -translate-x-1/2 top-7 flex flex-col items-center">
            <span className="text-white/90 text-xl font-bold tracking-widest tabular-nums drop-shadow-md">12:43</span>
            <div className={`text-[10px] font-medium tracking-wider uppercase transition-opacity duration-300 flex items-center gap-1 ${isAutoSaving ? 'opacity-70 text-[#FFB088]' : 'opacity-0 text-white/30'}`}>
              <span className="material-symbols-outlined text-[10px]">cloud_upload</span> Saved
            </div>
          </div>
          <button 
            onClick={handleEndSession}
            className="group flex items-center justify-center gap-2 bg-white/5 backdrop-blur-xl hover:bg-red-500/20 active:bg-red-500/30 transition-all rounded-full pl-4 pr-5 py-2 border border-white/10 hover:border-red-500/30 shadow-sm"
          >
            <span className="material-symbols-outlined text-red-300 group-hover:text-red-200 text-[20px]">call_end</span>
            <span className="text-sm font-semibold text-red-100/90 group-hover:text-white">End</span>
          </button>
        </div>
      </header>

      <div className="shrink-0 flex flex-col items-center justify-center pt-2 pb-6 gap-5 z-10 relative">
        <div className="relative flex items-center justify-center">
           {/* Ambient Glow Pulse */}
           <div className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-20 bg-[#FFB088]/30 rounded-full blur-[40px] transition-all duration-500 ${isListening ? 'opacity-100 scale-125' : 'opacity-0 scale-75'}`}></div>
           
           <div aria-hidden="true" className="flex items-center gap-1.5 h-16 relative z-10">
            <div style={{ animationDuration: isListening ? '0.6s' : '2s' }} className={`w-1.5 rounded-full h-4 animate-wave-slow transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_8px_#FFB088]' : 'bg-white/10'}`}></div>
            <div style={{ animationDuration: isListening ? '0.5s' : '1.5s' }} className={`w-1.5 rounded-full h-8 animate-wave-medium transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_8px_#FFB088]' : 'bg-white/20'}`}></div>
            <div style={{ animationDuration: isListening ? '0.4s' : '1s' }} className={`w-1.5 rounded-full h-12 animate-wave-fast shadow-[0_0_10px_rgba(255,176,136,0.4)] transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_12px_#FFB088]' : 'bg-white/30'}`}></div>
            <div style={{ animationDuration: isListening ? '0.5s' : '1.5s' }} className={`w-1.5 rounded-full h-8 animate-wave-medium shadow-[0_0_8px_rgba(255,176,136,0.3)] transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_10px_#FFB088]' : 'bg-white/30'}`}></div>
            <div style={{ animationDuration: isListening ? '0.4s' : '1s' }} className={`w-1.5 rounded-full h-14 animate-wave-fast delay-75 shadow-[0_0_12px_rgba(255,176,136,0.5)] transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_15px_#FFB088]' : 'bg-white/30'}`}></div>
            <div style={{ animationDuration: isListening ? '0.6s' : '2s' }} className={`w-1.5 rounded-full h-6 animate-wave-slow transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_8px_#FFB088]' : 'bg-white/30'}`}></div>
            <div style={{ animationDuration: isListening ? '0.5s' : '1.5s' }} className={`w-1.5 rounded-full h-10 animate-wave-medium transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_10px_#FFB088]' : 'bg-white/20'}`}></div>
            <div style={{ animationDuration: isListening ? '0.6s' : '2s' }} className={`w-1.5 rounded-full h-4 animate-wave-slow transition-all duration-300 ${isListening ? 'bg-[#FFB088] shadow-[0_0_8px_#FFB088]' : 'bg-white/10'}`}></div>
          </div>
        </div>
        
        <p className={`text-sm font-medium tracking-wide flex items-center gap-2 px-4 py-1.5 rounded-full border backdrop-blur-sm transition-all duration-300 ${isListening ? 'bg-[#FFB088]/10 border-[#FFB088]/30 text-[#FFB088] shadow-[0_0_15px_rgba(255,176,136,0.2)]' : 'bg-black/20 border-white/5 text-white/40'}`}>
          <span className={`material-symbols-outlined text-[18px] ${isListening ? 'animate-pulse' : ''}`}>graphic_eq</span>
          {isListening ? `Listening (${selectedLang.native})...` : 'Tap mic to speak'}
        </p>
      </div>

      <main className="flex-1 overflow-y-auto no-scrollbar px-4 pb-4 space-y-6 flex flex-col z-10 relative">
        <div className="fixed top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#1F1C1A] via-[#1F1C1A]/90 to-transparent pointer-events-none z-10"></div>
        
        <div className="mt-auto flex flex-col gap-6 pt-10">
          
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex items-end gap-3 max-w-[90%] group ${msg.sender === 'user' ? 'self-end flex-row-reverse' : 'self-start'}`}
            >
              {/* Avatar */}
              <div 
                className={`w-10 h-10 rounded-full overflow-hidden shrink-0 border-2 shadow-lg bg-cover bg-center ${msg.sender === 'user' ? 'border-[#FFB088]/30' : 'border-white/10 bg-white/10'}`} 
                style={{
                  backgroundImage: msg.sender === 'user' 
                    ? "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAmSnWAHmsGxCthJInatgYSvtbnvwKle5AbXklk2e4LKXi4aYl5Pjc-hwlga8SmLRPbG6FJ3YzYz4RzHhNgPlVzRD6ZgPznJvAR8TINjVoWfAfzWX8HuEqBl1zzgU0oGhJnxTxUf6xJPZKk3YCEZkvjVAiTJWgU94pMeQ1m4OCTKxA56eLW1PKIStu4WYePMvj8vSN3SCEtZdA3E54XDbmC1b50VcnjonKReF-WRL6fzStUH8NfDMXAkOrGZoIN1PgLE4Nu-bVTrR4')"
                    : "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCH2QULWmU227MbsQfBVkErS88_fwsIUcatC8pLVF52yJG44c7-hm13z6ibhgtJhCYLmQtaOULpA2xip7Dg-OZOKpkR8K0FlxoQl3oG9zLyS0_FyXMBTK7N_zB9koNiOpUEVTj5w0K59cKJWna9m2cK0hXb_VUWw62dF3T5hZHmBEEvNoRqKDBtu6-X1MXcONPMETNJyC17HgiM30jbKsReRiAC4pnsYOJbMJ98IM4FgpgnAlRm5C2coO4Mn_dNSKYOP78pszxhCM4')"
                }}
              ></div>
              
              <div className={`flex flex-col gap-1.5 ${msg.sender === 'user' ? 'items-end' : ''}`}>
                <span className={`text-white/50 text-xs font-medium tracking-wide ${msg.sender === 'user' ? 'mr-4' : 'ml-4'}`}>
                  {msg.sender === 'user' ? 'You' : 'Recall'}
                </span>
                
                <div 
                  className={`px-5 py-4 rounded-2xl shadow-sm text-[17px] leading-relaxed ${
                    msg.sender === 'user' 
                      ? 'bg-[linear-gradient(135deg,#FFB088_0%,#FF9E7D_100%)] shadow-[0_4px_15px_rgba(255,158,125,0.2)] text-[#3a281c] font-semibold rounded-br-none' 
                      : 'bg-[linear-gradient(135deg,rgba(255,255,255,0.1),rgba(255,255,255,0.05))] backdrop-blur-md border border-white/10 text-white/90 font-light rounded-bl-none'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>
              </div>
            </div>
          ))}

          {/* AI Thinking Indicator */}
          {isThinking && (
            <div className="flex items-end gap-3 max-w-[90%] self-start group animate-[fadeIn_0.3s_ease-out]">
              <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-white/10 shadow-lg bg-white/10 bg-cover bg-center" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDYTe-3l0TLvHpzWnzBFpXfA-UlryNr4uR-BXGtH7U5XQDmm5m04grqKVswRNfVb-3GpppV1Tf3GCmc4PfF29w5_TXc_aq1e1stWh3wpuLMGcQ1236RvhrBovzOMwfgS1cA4HVVqq0tvMk-KL4E5zzdLm5fTahpaG2QcWLUptXaCG6-IpMjXvS2pTu25q_fvmSwRHOk-lzZYEFnzJP-oJBP8x38JV3u68Kyc6OnZscJM2ihOQAN8aVZBaeswhmaY1HQr0nG1w3_19s')"}}></div>
              <div className="flex flex-col gap-1.5">
                <span className="text-white/50 text-xs font-medium ml-4 tracking-wide">Recall</span>
                <div className="bg-[linear-gradient(135deg,rgba(255,255,255,0.1),rgba(255,255,255,0.05))] backdrop-blur-md border border-white/10 shadow-sm px-5 py-4 rounded-2xl rounded-bl-none flex items-center gap-1.5 h-[58px]">
                  <div className="w-2 h-2 bg-[#FFB088]/60 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-[#FFB088]/60 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-2 h-2 bg-[#FFB088]/60 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </main>

      <footer className="p-6 pt-4 shrink-0 flex items-center justify-center z-20 relative">
        {isInputMode ? (
          <div className="w-full max-w-lg bg-white/10 backdrop-blur-xl border border-white/10 p-2 rounded-[2rem] flex items-center gap-2 shadow-2xl animate-[float_0.3s_ease-out]">
            <button 
              onClick={() => setIsInputMode(false)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              <span className="material-symbols-outlined">keyboard_hide</span>
            </button>
            <div className="relative flex-1">
              <input
                ref={inputRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={isListening ? `Listening (${selectedLang.native})...` : "Type a message..."}
                className={`w-full bg-black/20 border ${isListening ? 'border-[#FFB088] ring-1 ring-[#FFB088]/20' : 'border-white/10'} rounded-2xl h-12 pl-4 pr-10 text-white placeholder:text-white/40 focus:outline-none focus:border-[#FFB088]/50 transition-all`}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              />
              <button
                onClick={handleVoiceInput}
                className={`absolute right-1 top-1 bottom-1 w-10 rounded-xl flex items-center justify-center transition-all ${isListening ? 'text-[#FFB088] bg-[#FFB088]/10' : 'text-white/50 hover:text-white hover:bg-white/10'}`}
                title="Voice input"
              >
                <span className={`material-symbols-outlined text-[20px] ${isListening ? 'animate-pulse' : ''}`}>
                  {isListening ? 'graphic_eq' : 'mic'}
                </span>
              </button>
            </div>
            <button 
              onClick={handleSend}
              disabled={!inputText}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${inputText ? 'bg-[#FFB088] text-[#1F1C1A] shadow-lg shadow-[#FFB088]/20' : 'bg-white/5 text-white/20'}`}
            >
              <span className="material-symbols-outlined filled">send</span>
            </button>
          </div>
        ) : (
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 px-6 py-3 rounded-[3rem] flex items-center gap-6 shadow-2xl bg-black/20 relative">
             {/* Language Menu Popover */}
            {showLangMenu && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 bg-[#2a2624] border border-white/15 rounded-2xl overflow-hidden shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] min-w-[200px] z-50 flex flex-col p-1.5 animate-[float_0.2s_ease-out] origin-bottom">
                 <div className="px-3 py-2 text-xs font-bold text-white/40 uppercase tracking-wider border-b border-white/5 mb-1">Select Language</div>
                 {LANGUAGES.map((lang) => (
                   <button 
                     key={lang.code}
                     onClick={() => { setSelectedLang(lang); setShowLangMenu(false); }}
                     className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all ${selectedLang.code === lang.code ? 'bg-[#FFB088]/20 text-[#FFB088]' : 'hover:bg-white/5 text-white/80'}`}
                   >
                     <span className="text-lg">{lang.flag}</span>
                     <div className="flex flex-col leading-none">
                       <span className="text-sm font-semibold">{lang.native}</span>
                       <span className="text-[10px] opacity-60">{lang.label}</span>
                     </div>
                     {selectedLang.code === lang.code && <span className="material-symbols-outlined text-[16px] ml-auto">check</span>}
                   </button>
                 ))}
              </div>
            )}

            <button 
              onClick={() => setIsInputMode(true)}
              aria-label="Open keyboard" 
              className="w-12 h-12 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              <span className="material-symbols-outlined text-[24px]">keyboard</span>
            </button>
            
            <button 
              onClick={() => setShowLangMenu(!showLangMenu)}
              className={`h-12 px-4 rounded-full flex items-center justify-center gap-2 border transition-all ${showLangMenu ? 'bg-white/10 border-white/20 text-white' : 'border-white/5 text-white/70 hover:text-white hover:bg-white/5'}`}
            >
               <span className="material-symbols-outlined text-[20px]">language</span>
               <span className="text-sm font-semibold uppercase tracking-wider">{selectedLang.code.split('-')[0]}</span>
            </button>

            <button 
              onClick={handleVoiceInput}
              className={`w-20 h-20 -mt-10 mb-2 rounded-full bg-gradient-to-b from-[#2a2624] to-[#1a1816] border border-white/10 flex items-center justify-center text-white shadow-[0_0_20px_rgba(255,176,136,0.3)] hover:scale-105 active:scale-95 transition-all group relative overflow-hidden ${isListening ? 'ring-4 ring-[#FFB088]/30 scale-110 shadow-[0_0_30px_rgba(255,176,136,0.5)]' : ''}`}
            >
              <div className={`absolute inset-0 bg-[#FFB088]/10 rounded-full transition-all ${isListening ? 'animate-pulse' : 'group-hover:bg-[#FFB088]/20'}`}></div>
              <div className="absolute inset-0 rounded-full border border-[#FFB088]/30 opacity-50 group-hover:opacity-100 transition-opacity"></div>
              {/* Ripple Effect for active state */}
              {isListening && (
                <>
                  <div className="absolute inset-0 rounded-full border border-[#FFB088] animate-[ping_1.5s_cubic-bezier(0,0,0.2,1)_infinite] opacity-50"></div>
                  <div className="absolute inset-0 rounded-full border border-[#FFB088] animate-[ping_1.5s_cubic-bezier(0,0,0.2,1)_infinite_0.5s] opacity-30"></div>
                </>
              )}
              <span className={`material-symbols-outlined text-[36px] text-[#FFB088] group-hover:text-white transition-colors relative z-10 ${isListening ? 'animate-pulse' : ''}`}>
                {isListening ? 'graphic_eq' : 'mic'}
              </span>
            </button>

            <button aria-label="Pause session" className="w-12 h-12 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors">
              <span className="material-symbols-outlined text-[24px]">pause</span>
            </button>
          </div>
        )}
      </footer>
    </div>
  );
}