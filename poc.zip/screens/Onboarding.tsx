import React, { useState } from 'react';
import { Screen } from '../types';

interface Props {
  onNavigate: (screen: Screen) => void;
}

export default function Onboarding({ onNavigate }: Props) {
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [listening, setListening] = useState<'name' | 'email' | null>(null);

  const handleVoiceInput = (field: 'name' | 'email') => {
    if (listening) return;
    setListening(field);
    
    // Simulate voice recognition delay and transcription
    setTimeout(() => {
      setListening(null);
      setFormData(prev => ({
        ...prev,
        [field]: field === 'name' ? 'Grandma Joyce' : 'joyce.m@example.com'
      }));
    }, 2000);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 sm:p-6 bg-[#2A2320] font-['Spline_Sans']">
       {/* Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 bg-[linear-gradient(135deg,#1C1816_0%,#2A2320_100%)]">
        <div className="absolute top-[-5%] right-[-15%] w-96 h-96 bg-[#E08E6D]/10 rounded-full blur-[80px]"></div>
        <div className="absolute bottom-[10%] left-[-10%] w-72 h-72 bg-[#E08E6D]/5 rounded-full blur-[60px]"></div>
        <div className="absolute top-[30%] left-[20%] w-48 h-48 bg-[#D4A373]/10 rounded-full blur-[50px]"></div>
      </div>

      <div className="bg-[#2A2320]/65 backdrop-blur-xl border border-white/10 w-full max-w-[400px] rounded-3xl shadow-[0_8px_32px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden relative">
        <div className="px-8 pt-10 pb-4 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold tracking-widest text-[#E08E6D] uppercase">Step 1 of 2</span>
          </div>
          <div className="flex w-full gap-2 px-2">
            <div className="h-1.5 w-1/2 rounded-full bg-[#E08E6D] shadow-sm"></div>
            <div className="h-1.5 w-1/2 rounded-full bg-white/10"></div>
          </div>
        </div>

        <div className="px-8 pb-4">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-serif font-semibold leading-tight tracking-tight text-white mb-3">
              Who are we celebrating?
            </h1>
            <p className="text-gray-400 text-sm leading-relaxed">
              We'll help you capture the priceless memories of the senior you love.
            </p>
          </div>

          <div className="flex flex-col gap-6">
            <label className="flex flex-col gap-2 group">
              <span className="text-sm font-semibold text-gray-200 pl-1">Senior's Name</span>
              <div className="relative">
                <input 
                  className={`bg-black/20 border backdrop-blur-sm w-full rounded-2xl h-14 px-5 pl-5 pr-14 text-base text-white placeholder:text-gray-500 focus:border-[#E08E6D] focus:ring-2 focus:ring-[#E08E6D]/20 focus:bg-black/30 transition-all duration-300 ${listening === 'name' ? 'border-[#E08E6D] ring-2 ring-[#E08E6D]/20' : 'border-white/5'}`}
                  placeholder={listening === 'name' ? "Listening..." : "e.g., Grandma Joyce"}
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
                <button 
                  onClick={() => handleVoiceInput('name')}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all duration-300 ${listening === 'name' ? 'bg-[#E08E6D] text-white shadow-lg shadow-[#E08E6D]/20' : 'text-[#F3D8C6]/50 hover:text-[#E08E6D] hover:bg-white/5'}`}
                  title="Use voice input"
                >
                  <span className={`material-symbols-outlined text-[22px] ${listening === 'name' ? 'animate-pulse' : ''}`}>
                    {listening === 'name' ? 'graphic_eq' : 'mic'}
                  </span>
                </button>
              </div>
            </label>

            <label className="flex flex-col gap-2 group">
              <div className="flex justify-between items-end pl-1 pr-1">
                <span className="text-sm font-semibold text-gray-200">Senior's Email</span>
                <span className="text-xs text-gray-500 bg-white/10 px-2 py-0.5 rounded-md">Optional</span>
              </div>
              <div className="relative">
                <input 
                  className={`bg-black/20 border backdrop-blur-sm w-full rounded-2xl h-14 px-5 pl-5 pr-14 text-base text-white placeholder:text-gray-500 focus:border-[#E08E6D] focus:ring-2 focus:ring-[#E08E6D]/20 focus:bg-black/30 transition-all duration-300 ${listening === 'email' ? 'border-[#E08E6D] ring-2 ring-[#E08E6D]/20' : 'border-white/5'}`}
                  placeholder={listening === 'email' ? "Listening..." : "name@example.com"}
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
                <button 
                  onClick={() => handleVoiceInput('email')}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all duration-300 ${listening === 'email' ? 'bg-[#E08E6D] text-white shadow-lg shadow-[#E08E6D]/20' : 'text-[#F3D8C6]/50 hover:text-[#E08E6D] hover:bg-white/5'}`}
                  title="Use voice input"
                >
                  <span className={`material-symbols-outlined text-[22px] ${listening === 'email' ? 'animate-pulse' : ''}`}>
                    {listening === 'email' ? 'graphic_eq' : 'mic'}
                  </span>
                </button>
              </div>
            </label>
          </div>
        </div>

        <div className="flex-1 min-h-[32px]"></div>

        <div className="px-8 pb-8 pt-2 flex flex-col gap-4">
          <button 
            onClick={() => onNavigate(Screen.DASHBOARD)}
            className="w-full h-14 bg-[#E08E6D] hover:bg-[#d67e5b] text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-[#E08E6D]/20 hover:shadow-[#E08E6D]/40 active:scale-[0.98] transition-all duration-300 group"
          >
            Next: Your Info
            <span className="material-symbols-outlined text-[20px] transition-transform duration-300 group-hover:translate-x-1">
              arrow_forward
            </span>
          </button>
          <button 
            onClick={() => onNavigate(Screen.LANDING)}
            className="w-full h-10 text-gray-400 hover:text-[#F3D8C6] font-medium text-sm flex items-center justify-center transition-colors duration-200"
          >
            Back
          </button>
        </div>
        
        {/* Subtle noise texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.05]" style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAe9b87hf9GjbtzpfRJyjDf5lTK4t_bfMxjMs25z7FQZuLVnnFFtrfif4FsCaS1zapvJ-qP-r7aHVdUoFVIjKKcrC111gkqCuPgLCVWCJCSk0_dwfzyBNVNhnGLV2DsPYP_ybm2LFQoHTVzOT9dulcufRG2mzquKABxue3VXmKtgitCs80HUlsUPX8yipRmLlItW64UP-Dws9f7MHVEY8bGbQgFMtN4_qOG3TmHb8xx2gS7iM-4xx8q1uR6C7AtlzPBLA5_JJc8EJ4')" }}></div>
      </div>
    </div>
  );
}