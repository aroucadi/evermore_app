import React, { useState, useEffect, useMemo } from 'react';
import { Screen } from '../types';

interface Props {
  onNavigate: (screen: Screen) => void;
}

export default function ChapterDetail({ onNavigate }: Props) {
  // Audio Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [currentTime, setCurrentTime] = useState(260); // Start at 4:20 for demo
  const totalDuration = 840; // 14:00 minutes in seconds

  // Generate static waveform heights once
  const waveformHeights = useMemo(() => Array.from({ length: 50 }, () => Math.floor(Math.random() * 70) + 30), []);

  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = (currentTime / totalDuration) * 100;

  // Toggle Playback Speed
  const toggleSpeed = () => {
    const speeds = [1.0, 1.5, 2.0];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    setPlaybackSpeed(speeds[nextIdx]);
  };

  // Seek handler
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = (Number(e.target.value) / 100) * totalDuration;
    setCurrentTime(newTime);
  };

  // Playback Simulation
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return totalDuration;
          }
          return prev + 1;
        });
      }, 1000 / playbackSpeed);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed]);

  return (
    <div className="bg-[#262321] font-['Spline_Sans'] text-gray-100 antialiased selection:bg-[#D97757]/30 selection:text-white transition-colors duration-300 min-h-screen">
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-[#262321]">
        <div className="absolute -top-[10%] -left-[10%] w-[60%] h-[50%] bg-orange-900/20 blur-[100px] rounded-full mix-blend-screen"></div>
        <div className="absolute top-[30%] -right-[10%] w-[50%] h-[50%] bg-[#D97757]/5 blur-[100px] rounded-full"></div>
      </div>

      <div className="relative flex flex-col min-h-screen pb-36 z-10">
        <header className="sticky top-0 z-40 flex items-center justify-between px-6 py-4 transition-all">
          <button 
            onClick={() => onNavigate(Screen.FAMILY_PORTAL)}
            aria-label="Go back to chapters" 
            className="bg-white/10 border border-white/15 backdrop-blur-md flex items-center justify-center size-14 rounded-full hover:bg-white/20 active:scale-95 transition-all shadow-sm group"
          >
            <span className="material-symbols-outlined text-gray-100 group-hover:-translate-x-0.5 transition-transform">arrow_back_ios_new</span>
          </button>
          <button aria-label="Menu" className="bg-white/10 border border-white/15 backdrop-blur-md flex items-center justify-center size-14 rounded-full hover:bg-white/20 active:scale-95 transition-all shadow-sm">
            <span className="material-symbols-outlined text-gray-100">more_horiz</span>
          </button>
        </header>

        <main className="flex-1 flex flex-col px-6 pt-4 gap-8 max-w-3xl mx-auto w-full">
          <section className="flex flex-col gap-4 animate-[fadeIn_0.5s_ease-out]">
            <div className="flex flex-wrap items-center gap-3 text-base font-medium">
              <span className="px-4 py-1.5 rounded-full bg-[#D97757]/10 text-[#D97757] border border-[#D97757]/20 backdrop-blur-sm">
                Session 4
              </span>
              <span className="text-gray-400 font-display flex items-center gap-1">
                <span className="material-symbols-outlined text-[18px]">calendar_today</span> Oct 12, 2023
              </span>
              <span className="text-gray-600">•</span>
              <span className="text-gray-400 font-display">14 mins</span>
            </div>
            <h1 className="text-[2.5rem] leading-[1.15] font-bold tracking-tight text-white font-serif">
              The Summer of '69 at Lake Tahoe
            </h1>
          </section>

          <section className="w-full relative group">
            <div className="bg-[#282828]/60 border border-white/10 backdrop-blur-xl p-5 rounded-[2rem] shadow-xl shadow-orange-900/5 relative overflow-hidden transition-transform hover:scale-[1.01] duration-500">
              <div className="absolute -top-20 -right-20 w-56 h-56 bg-[#D97757]/15 rounded-full blur-3xl"></div>
              
              {/* Player Top Section */}
              <div className="flex items-center gap-5 relative z-10 mb-6">
                <div className="relative size-20 shrink-0 rounded-2xl overflow-hidden shadow-md ring-1 ring-white/10 group/img">
                  <img alt="Scenic view" className="object-cover size-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA2LoWs1mrFv6Atj3TlHpfKpMObw5ZsZmG6sk7KOy2ljIk_h4bNrcLQJ13ldp0AYfp8_-NACl_hX2LwSl7w0gX0ntwRJ7pAmXrnFlSwRPhWRf8j6T9-u5aX_dkO7GtMAJP_ugelSdNF21fx06FypWJR7Yz7gYypsG2Nu-irJyNfXDXue7lTu-MOwABlldNnX5jW_q0hKTdoeXIhDdxZmDr9GHKuJFWmox2LSEWcsJ9yvR2N3W4p8L-7jZT5l7A7KPXwwqCIZqbex9M" />
                  <div className="absolute inset-0 bg-gradient-to-tr from-black/20 to-transparent"></div>
                  {/* Mini equalizer overlay on the image when playing */}
                  <div className={`absolute inset-0 bg-black/30 flex items-end justify-center gap-0.5 pb-2 transition-opacity duration-300 ${isPlaying ? 'opacity-100' : 'opacity-0'}`}>
                    <div className="w-1 bg-white/90 h-3 animate-[wave-slow_1s_infinite]"></div>
                    <div className="w-1 bg-white/90 h-5 animate-[wave-fast_0.8s_infinite]"></div>
                    <div className="w-1 bg-white/90 h-4 animate-[wave-medium_1.2s_infinite]"></div>
                  </div>
                </div>
                
                <div className="flex-1 min-w-0 flex flex-col justify-center gap-1">
                  <h3 className="text-xl font-bold text-white truncate leading-tight font-display">Highlight Reel</h3>
                  <div className="flex items-center gap-2 text-base">
                    <span className="text-[#D97757] font-bold tabular-nums">{formatTime(currentTime)}</span>
                    <span className="text-gray-500 font-medium tabular-nums">/ {formatTime(totalDuration)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                     <span className="text-xs font-bold text-[#D97757] bg-[#D97757]/10 px-2.5 py-1.5 rounded-lg border border-[#D97757]/20 tabular-nums transition-all">
                      {playbackSpeed.toFixed(1)}x
                    </span>
                    <button 
                      onClick={toggleSpeed}
                      className="group/speed h-10 w-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-all"
                      title="Change playback speed"
                    >
                      <span className="material-symbols-outlined text-[20px] group-hover/speed:rotate-180 transition-transform duration-500">settings_motion</span>
                    </button>
                  </div>

                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="flex shrink-0 items-center justify-center rounded-full size-16 bg-gradient-to-br from-[#D97757] to-[#C05632] text-white shadow-xl shadow-[#D97757]/30 hover:scale-105 active:scale-95 transition-all ring-4 ring-white/5"
                  >
                    <span className={`material-symbols-outlined filled text-[32px] ml-0.5 ${isPlaying ? '' : 'ml-1'}`}>
                      {isPlaying ? 'pause' : 'play_arrow'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Seek Bar / Waveform Section */}
              <div className="relative z-10 px-1 pb-2 h-12 flex items-center group/slider">
                {/* Waveform Visualization */}
                <div className="absolute inset-0 flex items-center justify-between gap-[3px] pointer-events-none px-1">
                  {waveformHeights.map((height, i) => {
                     const barPercent = (i / waveformHeights.length) * 100;
                     const isPlayed = barPercent <= progressPercent;
                     return (
                        <div 
                          key={i} 
                          className={`w-1.5 rounded-full transition-all duration-200 ${isPlayed ? 'bg-[#D97757]' : 'bg-white/10'}`}
                          style={{ height: `${height}%` }}
                        ></div>
                     );
                  })}
                </div>

                {/* Invisible Range Input for Interaction */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="0.1"
                  value={progressPercent}
                  onChange={handleSeek}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                  aria-label="Seek audio"
                />

                {/* Scrubber Handle */}
                 <div 
                    className="absolute h-full w-0.5 bg-white/0 z-10 pointer-events-none transition-all duration-75"
                    style={{ left: `${progressPercent}%` }}
                 >
                    <div className="absolute top-1/2 -translate-y-1/2 -left-3 w-6 h-6 bg-white rounded-full shadow-[0_2px_10px_rgba(0,0,0,0.3)] scale-0 group-hover/slider:scale-100 transition-transform flex items-center justify-center">
                        <div className="w-2 h-2 bg-[#D97757] rounded-full"></div>
                    </div>
                 </div>
              </div>
            </div>
          </section>

          <article className="mt-4 mb-6 relative">
            <div className="absolute left-0 top-3 bottom-3 w-0.5 bg-gradient-to-b from-transparent via-[#D97757]/20 to-transparent rounded-full hidden md:block"></div>
            <div className="md:pl-8">
              <p className="text-2xl leading-[1.7] text-gray-200 mb-8 font-serif">
                It started on a Tuesday, the kind of Tuesday where the sun feels like it's trying to make up for a whole week of rain. We packed the station wagon until it was bursting at the seams.
              </p>
              <div className="relative my-10 p-8 rounded-2xl bg-white/5 border border-white/5 shadow-sm overflow-hidden">
                <div className="absolute -left-4 -top-4 text-[8rem] text-[#D97757]/10 font-serif leading-none select-none">“</div>
                <p className="relative z-10 text-[1.6rem] leading-relaxed text-white italic font-serif font-medium text-center">
                  If we fit one more suitcase in here, the wheels are gonna pop off!
                </p>
              </div>
              <p className="text-2xl leading-[1.7] text-gray-200 mb-8 font-serif">
                 Dad shouted from the driveway, wiping sweat from his forehead. We all laughed, but I think he was half serious. The drive up to the lake was winding, filled with the smell of pine needles and anticipation.
              </p>
              <p className="text-2xl leading-[1.7] text-gray-200 mb-8 font-serif">
                That summer was different. It was the year I learned to fish, really fish, not just hold the pole. It was also the year everything felt... simpler. The water was crystal clear, cold enough to take your breath away, but we jumped in anyway. We spent hours skipping stones near the dock, counting ripples until the sun dipped below the pines.
              </p>
              <p className="text-2xl leading-[1.7] text-gray-200 font-serif">
                Grandma Rose would sit on the porch swing, snapping beans and humming that old tune she loved. Even now, if I close my eyes, I can still hear the creak of the swing chains and the distant splash of a trout jumping.
              </p>
            </div>
          </article>

          <section className="py-8 border-t border-white/10">
            <h2 className="text-sm font-bold uppercase tracking-widest text-[#D97757]/70 mb-5 pl-1">Mentioned in this story</h2>
            <div className="flex flex-wrap gap-3">
              <button className="group flex items-center gap-3 pl-2 pr-5 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#D97757]/40 hover:bg-white/10 hover:shadow-md transition-all">
                <div className="size-10 rounded-full bg-[#D97757]/10 flex items-center justify-center text-[#D97757] group-hover:bg-[#D97757] group-hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl filled">person</span>
                </div>
                <span className="text-lg font-medium text-gray-200 font-display">Grandma Rose</span>
              </button>
              <button className="group flex items-center gap-3 pl-2 pr-5 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#D97757]/40 hover:bg-white/10 hover:shadow-md transition-all">
                <div className="size-10 rounded-full bg-[#D97757]/10 flex items-center justify-center text-[#D97757] group-hover:bg-[#D97757] group-hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl filled">location_on</span>
                </div>
                <span className="text-lg font-medium text-gray-200 font-display">Lake Tahoe</span>
              </button>
              <button className="group flex items-center gap-3 pl-2 pr-5 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#D97757]/40 hover:bg-white/10 hover:shadow-md transition-all">
                <div className="size-10 rounded-full bg-[#D97757]/10 flex items-center justify-center text-[#D97757] group-hover:bg-[#D97757] group-hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl filled">phishing</span>
                </div>
                <span className="text-lg font-medium text-gray-200 font-display">Fishing</span>
              </button>
              <button className="group flex items-center gap-3 pl-2 pr-5 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#D97757]/40 hover:bg-white/10 hover:shadow-md transition-all">
                <div className="size-10 rounded-full bg-[#D97757]/10 flex items-center justify-center text-[#D97757] group-hover:bg-[#D97757] group-hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-xl filled">directions_car</span>
                </div>
                <span className="text-lg font-medium text-gray-200 font-display">Road Trip</span>
              </button>
            </div>
          </section>
        </main>

        <div className="fixed bottom-0 inset-x-0 p-6 pb-8 bg-gradient-to-t from-[#262321] via-[#262321]/95 to-transparent z-50 pointer-events-none">
          <div className="pointer-events-auto max-w-3xl mx-auto flex gap-4 p-2.5 rounded-[1.2rem] bg-white/10 backdrop-blur-md border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.12)]">
            <button className="flex-1 flex items-center justify-center gap-2 h-16 rounded-xl hover:bg-white/10 text-white font-bold transition-all active:scale-[0.98]">
              <span className="material-symbols-outlined">download</span>
              <span className="text-lg">PDF</span>
            </button>
            <button className="flex-[2] flex items-center justify-center gap-3 h-16 rounded-xl bg-[#D97757] text-white font-bold hover:bg-[#C05632] active:scale-[0.98] transition-all shadow-lg shadow-[#D97757]/30 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <span className="material-symbols-outlined text-[24px]">ios_share</span>
              <span className="text-lg tracking-wide">Share Story</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}