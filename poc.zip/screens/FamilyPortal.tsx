import React, { useState } from 'react';
import { Screen } from '../types';

interface Props {
  onNavigate: (screen: Screen) => void;
}

export default function FamilyPortal({ onNavigate }: Props) {
  const [searchText, setSearchText] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleVoiceSearch = () => {
    if (isListening) return;
    setIsListening(true);
    
    // Simulate voice recognition delay and transcription
    setTimeout(() => {
      setIsListening(false);
      setSearchText('The Summer of 65');
    }, 2000);
  };

  return (
    <div className="font-['Spline_Sans'] antialiased text-[#4a4238] min-h-screen flex flex-col selection:bg-[#d97757]/20 bg-[#fdfbf7]">
      {/* Background */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0 bg-[radial-gradient(circle_at_10%_20%,#fdfbf7_0%,#fcf6f0_40%,#f5eee6_100%)]">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-[#d97757]/5 rounded-full blur-3xl opacity-60"></div>
        <div className="absolute bottom-[20%] left-[-20%] w-[400px] h-[400px] bg-[#f4a261]/5 rounded-full blur-3xl opacity-60"></div>
      </div>

      <header className="relative pt-6 px-5 pb-2 sticky top-0 z-30 transition-all duration-300">
        <div className="absolute inset-0 bg-[#fcf6f0]/80 backdrop-blur-md -z-10 border-b border-white/20 shadow-sm"></div>
        <div className="relative flex justify-between items-center mb-6 pt-2">
          <div className="flex items-center gap-4">
            <div className="relative cursor-pointer group" onClick={() => onNavigate(Screen.DASHBOARD)}>
              <div className="bg-center bg-no-repeat bg-cover rounded-full h-14 w-14 ring-4 ring-white shadow-md group-hover:scale-105 transition-transform" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuBfcFK6-jWC3iVMbNXfAvjTmZ7am8DPcnVwpDzz7DHNBKaahKftnDh9b6AoTqhU21Hmzu3ZJbZvLvLMFSPXiUY37MD5ufKOU_VDOcczWd9f1bcGxaM_-gauPtrlpDDOCgQ_b8bdApp5H06YeH-6z2cCixm53G-MSTnJQz8s4syqBD0I6B9HK94sSOR4ew--0RxA70eNhFOrZxElfTnbTjveEaLflZdZ22YsM1ZYr7mGSytiUlEiGdpSgSl3lVoEkcm60AS3w3CVMAw")'}}></div>
              <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full shadow-sm">
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-serif font-bold leading-tight tracking-tight text-[#4a4238]">Arthur's Chapters</h1>
              <p className="text-[#8c8174] text-sm font-medium flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px] text-[#d97757]">family_history</span>
                Family Library
              </p>
            </div>
          </div>
          <button className="flex items-center justify-center w-11 h-11 rounded-full bg-white/60 hover:bg-white border border-white/50 shadow-sm transition-all text-[#8c8174] hover:text-[#d97757]">
            <span className="material-symbols-outlined filled">notifications</span>
          </button>
        </div>
        <div className="relative mb-2">
          <label className={`group flex items-center w-full h-12 bg-white/50 backdrop-blur-md border rounded-2xl overflow-hidden transition-all ${isListening ? 'border-[#d97757] ring-1 ring-[#d97757]/20 bg-white/80' : 'border-white/30 focus-within:bg-white/80 focus-within:shadow-md focus-within:border-[#d97757]/30'}`}>
            <div className={`flex items-center justify-center pl-4 pr-3 transition-colors ${isListening ? 'text-[#d97757]' : 'text-[#8c8174] group-focus-within:text-[#d97757]'}`}>
              <span className="material-symbols-outlined text-[22px]">search</span>
            </div>
            <input 
              className="w-full bg-transparent border-none focus:ring-0 text-[#4a4238] placeholder:text-[#8c8174]/70 text-base font-normal h-full outline-none" 
              placeholder={isListening ? "Listening..." : "Search memories (e.g., 'Wedding', 'Ship')..."}
              type="text"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
            <button 
              onClick={handleVoiceSearch}
              className={`mr-2 p-1.5 rounded-xl transition-all ${isListening ? 'bg-[#d97757] text-white shadow-md' : 'text-[#8c8174] hover:bg-[#d97757]/10 hover:text-[#d97757]'}`}
            >
              <span className={`material-symbols-outlined text-[20px] block ${isListening ? 'animate-pulse' : ''}`}>
                {isListening ? 'graphic_eq' : 'mic'}
              </span>
            </button>
          </label>
        </div>
      </header>

      <div className="sticky top-[146px] z-20 pb-4 pt-1">
        <div className="absolute inset-0 bg-[#fcf6f0]/90 backdrop-blur-xl -z-10 [mask-image:linear-gradient(to_bottom,black,transparent)]"></div>
        <div className="flex gap-3 px-5 overflow-x-auto no-scrollbar py-2">
          <button className="flex h-10 shrink-0 items-center justify-center px-6 rounded-full bg-[#d97757] text-white font-medium text-sm shadow-lg shadow-[#d97757]/20 transition-transform active:scale-95 border border-[#d97757]">
            All
          </button>
          <button className="flex h-10 shrink-0 items-center justify-center px-6 rounded-full bg-white/60 border border-white/60 text-[#8c8174] font-medium text-sm hover:bg-white hover:text-[#d97757] hover:shadow-md transition-all active:scale-95 backdrop-blur-sm">
            Early Life
          </button>
          <button className="flex h-10 shrink-0 items-center justify-center px-6 rounded-full bg-white/60 border border-white/60 text-[#8c8174] font-medium text-sm hover:bg-white hover:text-[#d97757] hover:shadow-md transition-all active:scale-95 backdrop-blur-sm">
            Career
          </button>
          <button className="flex h-10 shrink-0 items-center justify-center px-6 rounded-full bg-white/60 border border-white/60 text-[#8c8174] font-medium text-sm hover:bg-white hover:text-[#d97757] hover:shadow-md transition-all active:scale-95 backdrop-blur-sm">
            Romance
          </button>
          <button className="flex h-10 shrink-0 items-center justify-center px-6 rounded-full bg-white/60 border border-white/60 text-[#8c8174] font-medium text-sm hover:bg-white hover:text-[#d97757] hover:shadow-md transition-all active:scale-95 backdrop-blur-sm">
            Navy
          </button>
        </div>
      </div>

      <main className="flex-1 px-5 pb-6 space-y-5 z-10">
        {/* Card 1 */}
        <article onClick={() => onNavigate(Screen.CHAPTER_DETAIL)} className="group relative flex flex-col gap-3 bg-[linear-gradient(135deg,rgba(255,255,255,0.9),rgba(255,255,255,0.6))] backdrop-blur-md border border-white/80 p-5 rounded-3xl transition-all active:scale-[0.99] touch-manipulation hover:shadow-[0_8px_32px_0_rgba(74,66,56,0.08)] hover:-translate-y-0.5 cursor-pointer">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center rounded-2xl bg-blue-50 text-blue-500 shrink-0 h-14 w-14 shadow-inner ring-1 ring-blue-100">
                <span className="material-symbols-outlined text-[28px]">sailing</span>
              </div>
              <div>
                <h2 className="text-[#4a4238] text-lg font-serif font-bold leading-tight">Chapter 4: The Navy Days</h2>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-[11px] font-bold tracking-wide uppercase bg-blue-100/50 text-blue-700 px-2.5 py-1 rounded-lg border border-blue-100">Navy</span>
                  <span className="text-[#8c8174] text-xs flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-[#8c8174]/40"></span> Oct 14, 2023
                  </span>
                </div>
              </div>
            </div>
            <button className="h-9 w-9 rounded-full flex items-center justify-center text-[#8c8174] hover:bg-[#e8e1d9]/30 transition-colors">
              <span className="material-symbols-outlined">more_horiz</span>
            </button>
          </div>
          <p className="text-[#4a4238]/80 text-[15px] leading-relaxed line-clamp-2 pl-1">
            The ocean looked different at night. I remember standing on the deck, watching the phosphorescence in the wake of the ship...
          </p>
          <div className="flex items-center justify-between pt-3 border-t border-black/5 mt-1">
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full bg-white/50 border border-white/60 hover:bg-[#d97757] hover:border-[#d97757] hover:text-white transition-all shadow-sm group/play">
                <span className="material-symbols-outlined text-[22px] text-[#d97757] group-hover/play:text-white">play_circle</span>
                <span className="text-xs font-semibold text-[#8c8174] group-hover/play:text-white">4:20 Listen</span>
              </button>
              <span className="text-[#8c8174] text-xs font-medium opacity-70">1,240 words</span>
            </div>
            <div className="h-9 w-9 rounded-full bg-white/50 border border-white/60 flex items-center justify-center text-[#8c8174] group-hover:bg-[#d97757] group-hover:border-[#d97757] group-hover:text-white transition-all shadow-sm">
              <span className="material-symbols-outlined text-[20px]">chevron_right</span>
            </div>
          </div>
        </article>

        {/* Card 2 */}
        <article onClick={() => onNavigate(Screen.CHAPTER_DETAIL)} className="group relative flex flex-col gap-3 bg-[linear-gradient(135deg,rgba(255,255,255,0.9),rgba(255,255,255,0.6))] backdrop-blur-md border border-white/80 p-5 rounded-3xl transition-all active:scale-[0.99] touch-manipulation hover:shadow-[0_8px_32px_0_rgba(74,66,56,0.08)] hover:-translate-y-0.5 cursor-pointer">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center rounded-2xl bg-rose-50 text-rose-500 shrink-0 h-14 w-14 shadow-inner ring-1 ring-rose-100">
                <span className="material-symbols-outlined text-[28px] filled">favorite</span>
              </div>
              <div>
                <h2 className="text-[#4a4238] text-lg font-serif font-bold leading-tight">Chapter 3: Meeting Eleanor</h2>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-[11px] font-bold tracking-wide uppercase bg-rose-100/50 text-rose-700 px-2.5 py-1 rounded-lg border border-rose-100">Romance</span>
                  <span className="text-[#8c8174] text-xs flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-[#8c8174]/40"></span> Sep 22, 2023
                  </span>
                </div>
              </div>
            </div>
            <button className="h-9 w-9 rounded-full flex items-center justify-center text-[#8c8174] hover:bg-[#e8e1d9]/30 transition-colors">
              <span className="material-symbols-outlined">more_horiz</span>
            </button>
          </div>
          <p className="text-[#4a4238]/80 text-[15px] leading-relaxed line-clamp-2 pl-1">
            She was wearing a yellow dress. That's the first thing I noticed. Not the band playing, not the crowded dance floor, but that bright yellow...
          </p>
          <div className="flex items-center justify-between pt-3 border-t border-black/5 mt-1">
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full bg-white/50 border border-white/60 hover:bg-[#d97757] hover:border-[#d97757] hover:text-white transition-all shadow-sm group/play">
                <span className="material-symbols-outlined text-[22px] text-[#d97757] group-hover/play:text-white">play_circle</span>
                <span className="text-xs font-semibold text-[#8c8174] group-hover/play:text-white">8:15 Listen</span>
              </button>
              <span className="text-[#8c8174] text-xs font-medium opacity-70">2,100 words</span>
            </div>
            <div className="h-9 w-9 rounded-full bg-white/50 border border-white/60 flex items-center justify-center text-[#8c8174] group-hover:bg-[#d97757] group-hover:border-[#d97757] group-hover:text-white transition-all shadow-sm">
              <span className="material-symbols-outlined text-[20px]">chevron_right</span>
            </div>
          </div>
        </article>

        {/* Card 3 */}
        <article onClick={() => onNavigate(Screen.CHAPTER_DETAIL)} className="group relative flex flex-col gap-3 bg-[linear-gradient(135deg,rgba(255,255,255,0.9),rgba(255,255,255,0.6))] backdrop-blur-md border border-white/80 p-5 rounded-3xl transition-all active:scale-[0.99] touch-manipulation hover:shadow-[0_8px_32px_0_rgba(74,66,56,0.08)] hover:-translate-y-0.5 cursor-pointer">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 shrink-0 h-14 w-14 shadow-inner ring-1 ring-emerald-100">
                <span className="material-symbols-outlined text-[28px]">store</span>
              </div>
              <div>
                <h2 className="text-[#4a4238] text-lg font-serif font-bold leading-tight">Chapter 2: The Hardware Store</h2>
                <div className="flex items-center gap-2 mt-1.5">
                   <span className="text-[11px] font-bold tracking-wide uppercase bg-emerald-100/50 text-emerald-700 px-2.5 py-1 rounded-lg border border-emerald-100">Career</span>
                  <span className="text-[#8c8174] text-xs flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-[#8c8174]/40"></span> Aug 10, 2023
                  </span>
                </div>
              </div>
            </div>
            <button className="h-9 w-9 rounded-full flex items-center justify-center text-[#8c8174] hover:bg-[#e8e1d9]/30 transition-colors">
              <span className="material-symbols-outlined">more_horiz</span>
            </button>
          </div>
          <p className="text-[#4a4238]/80 text-[15px] leading-relaxed line-clamp-2 pl-1">
            My father taught me that if you treat a customer right, they'll come back for a lifetime. We didn't just sell hammers and nails...
          </p>
          <div className="flex items-center justify-between pt-3 border-t border-black/5 mt-1">
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 pl-2 pr-4 py-1.5 rounded-full bg-white/50 border border-white/60 hover:bg-[#d97757] hover:border-[#d97757] hover:text-white transition-all shadow-sm group/play">
                <span className="material-symbols-outlined text-[22px] text-[#d97757] group-hover/play:text-white">play_circle</span>
                <span className="text-xs font-semibold text-[#8c8174] group-hover/play:text-white">6:30 Listen</span>
              </button>
              <span className="text-[#8c8174] text-xs font-medium opacity-70">1,800 words</span>
            </div>
            <div className="h-9 w-9 rounded-full bg-white/50 border border-white/60 flex items-center justify-center text-[#8c8174] group-hover:bg-[#d97757] group-hover:border-[#d97757] group-hover:text-white transition-all shadow-sm">
              <span className="material-symbols-outlined text-[20px]">chevron_right</span>
            </div>
          </div>
        </article>
      </main>

       {/* Floating Action Button (FAB) */}
       <div className="fixed bottom-6 right-6 z-40">
        <button onClick={() => onNavigate(Screen.ACTIVE_CONVERSATION)} className="flex items-center justify-center w-16 h-16 rounded-full bg-[#d97757] text-white shadow-xl shadow-[#d97757]/40 hover:scale-105 active:scale-95 transition-all border-4 border-white/20">
          <span className="material-symbols-outlined text-[32px]">mic</span>
        </button>
      </div>
    </div>
  );
}